

<h1>웹디자인 기능사 실기 따라하면 딴다.</h1>
<ul>
  <li>01. 레이아웃 유형1(가로) <a href="https://webstoryboy.github.io/webd/webd01.html">VIEW</a></li>
  <li>02. 레이아웃 유형2(세로) <a href="https://webstoryboy.github.io/webd/webd02.html">VIEW</a></li>
  <li>03. 가로 메뉴 유형1 <a href="https://webstoryboy.github.io/webd/webd03.html">VIEW</a></li>
  <li>04. 가로 메뉴 유형2 <a href="https://webstoryboy.github.io/webd/webd04.html">VIEW</a></li>
  <li>05. 세로 메뉴 유형1 <a href="https://webstoryboy.github.io/webd/webd05.html">VIEW</a></li>
  <li>06. 세로 메뉴 유형2 <a href="https://webstoryboy.github.io/webd/webd06.html">VIEW</a></li>
  <li>07. 탭 메뉴 유형 <a href="https://webstoryboy.github.io/webd/webd07.html">VIEW</a></li>
  <li>08. 레이어 팝업 유형 <a href="https://webstoryboy.github.io/webd/webd09.html">VIEW</a></li>
  <li>09. 이미지 슬라이드(위아래) <a href="https://webstoryboy.github.io/webd/webd09.html">VIEW</a></li>
  <li>10. 이미지 슬라이드(좌우) <a href="https://webstoryboy.github.io/webd/webd11.html">VIEW</a></li>
  <li>11. 이미지 슬라이드(페이드) <a href="https://webstoryboy.github.io/webd/webd10.html">VIEW</a></li>
  <li>12. 실전사이트 만들기1 <a href="https://webstoryboy.github.io/webd/webd13.html">VIEW</a></li>
</ul>

<ul>
  <li>실전사이트 이미지1 <a href="https://webstoryboy.github.io/webd/Coding_img1.jpg">VIEW</a></li>
  <li>실전사이트 이미지2 <a href="https://webstoryboy.github.io/webd/Coding_img2.jpg">VIEW</a></li>
</ul>


<ul>
  <li>01. 웹디자인 기능사 따라하면 딴다 - INTRO | 웹스토리보이</li>
  <li>02. 웹디자인 기능사 따라하면 딴다 - 레이아웃1_1 | 웹스토리보이</li>
  <li>03. 웹디자인 기능사 따라하면 딴다 - 레이아웃1_2 | 웹스토리보이</li>
  <li>04. 웹디자인 기능사 따라하면 딴다 - 레이아웃2 | 웹스토리보이</li>
  <li>05. 웹디자인 기능사 따라하면 딴다 - 가로유형1 | 웹스토리보이</li>
  <li>06. 웹디자인 기능사 따라하면 딴다 - 가로유형2 | 웹스토리보이</li>
  <li>07. 웹디자인 기능사 따라하면 딴다 - 가로유형3 | 웹스토리보이</li>
  <li>08. 웹디자인 기능사 따라하면 딴다 - 세로유형1 | 웹스토리보이</li>
  <li>09. 웹디자인 기능사 따라하면 딴다 - 세로유형2 | 웹스토리보이</li>
  <li>10. 웹디자인 기능사 따라하면 딴다 - 탭 메뉴 유형 | 웹스토리보이</li>
  <li>11. 웹디자인 기능사 따라하면 딴다 - 레이어 팝업 유형 | 웹스토리보이</li>
  <li>12. 웹디자인 기능사 따라하면 딴다 - 이미지 슬라이드 유형1(위아래) | 웹스토리보이</li>
  <li>13. 웹디자인 기능사 따라하면 딴다 - 이미지 슬라이드 유형2(페이드) | 웹스토리보이</li>
  <li>14. 웹디자인 기능사 따라하면 딴다 - 이미지 슬라이드 유형3(좌우) | 웹스토리보이</li>
</ul>
